package main

import (
	"fmt"
	"strings"
)

//Напишите функцию, которая принимает срез целых чисел и возвращает новый срез, в котором каждое число возведено в квадрат.

func SquareArr(arr []int) (arr2 []int) {
	result := make([]int, len(arr))
	for i, v := range arr {
		result[i] = v * v
	}
	return result
}

//Реализуйте функцию, которая принимает срез строк и возвращает новый срез, содержащий строки в нижнем регистре.

func DownArr(str []string) []string {
	result := make([]string, len(str))
	for i, s := range str {
		result[i] = strings.ToLower(s)
	}
	return result
}

//Реализуйте функцию, которая принимает срез структур Car и возвращает структуру Car, у которой цена минимальна.

func AboutCar(car []struct{}) []struct{} {
	result := make([]struct{}, len(car))
	for i, v := range car {
		result[i] = v
	}
	return result
}

func main() {
	fmt.Println(SquareArr([]int{1, 2, 3, 4, 5}))
	strings := []string{"Hello", "WORLD", "Golang"}
	fmt.Println(DownArr(strings))

}
